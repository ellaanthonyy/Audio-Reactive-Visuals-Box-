let mic;
let fft;

function setup() {
  createCanvas(windowWidth, windowHeight);
  noFill();

  // Set up microphone input
  mic = new p5.AudioIn();
  mic.start();

  // Set up FFT for frequency analysis
  fft = new p5.FFT();
  fft.setInput(mic);
}

function draw() {
  background(10, 10, 30, 100); // Semi-transparent background for trails

  // Get the amplitude level
  let vol = mic.getLevel();
  
  // Map volume to a usable range for visuals
  let mappedVol = map(vol, 0, 1, 10, 200);

  // Draw central square reacting to volume
  stroke(lerpColor(color('#ff007f'), color('#00ffff'), vol));
  strokeWeight(3);
  rectMode(CENTER);
  rect(width / 2, height / 2, mappedVol, mappedVol);

  // Frequency analysis
  let spectrum = fft.analyze();

  // Draw frequency-reactive lines
  stroke(255, 150);
  for (let i = 0; i < spectrum.length; i += 10) {
    let amp = spectrum[i];
    let x = map(i, 0, spectrum.length, 0, width);
    let y = map(amp, 0, 255, height, 0);
    
    // Horizontal lines
    line(x, height / 2 - mappedVol / 2, x, y);

    // Vertical lines
    line(width / 2 - mappedVol / 2, x, y, x);
  }
}

function keyPressed() {
  if (key === 's') {
    mic.start(); // Start microphone input
  } else if (key === 'm') {
    mic.stop(); // Mute microphone
  }
}